const puppeteer = require('puppeteer')

const sleep = async ms => new Promise(resolve => setTimeout(resolve, ms))

const visit = async url => {
    const browser = await puppeteer.launch({headless: true,args: ['--no-sandbox']})
    const page = await browser.newPage();
    // 绕过ngrok浏览器警告
    await page.setExtraHTTPHeaders({
        "ngrok-skip-browser-warning": "69420"
    });
    await page.goto(url);
    await sleep(5000);
    await browser.close();
}
module.exports = visit