const express = require('express');
const http = require('http');
const {v4: uuidv4} = require('uuid');
const visit = require("./bot");
const https = require("https");
const router = express.Router();

const FLAG = process.env.FLAG || 'test{flag}'
let apis = new Map();

function randGenerate(minLength, maxLength) {
    const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    let randomStr = '';

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        randomStr += characters[randomIndex];
    }
    return randomStr;
}


function sendRequest(url, opts) {
    return new Promise((resolve, reject) => {
        opts['headers']['ngrok-skip-browser-warning'] = "69420" // 去除ngrok警告
        let sender;
        if (url.includes("https")) {
            opts['rejectUnauthorized'] = false
            sender = https;
        } else {
            sender = http;
        }
        sender.get(url, opts, (resp) => {
            let data = '';
            resp.on('data', (chunk) => {
                data += chunk;
            });
            resp.on('end', () => {
                resolve({resp, data});
            });
        }).on('error', (err) => {
            reject(err);
        });
    });
}


/* GET home page. */
router.get('/', function (req, res) {
    res.render('index', {title: 'Web Builder'});
});

/* let the bot visit.  */
router.get('/flag', function (req, res) {
    const ip = req.socket.remoteAddress;
    if (!ip.includes('127.0.0.1')) {
        console.log(ip)
        res.send("No Way");
    } else {
        console.log("Bot got the flag!");
        res.send("your highness, h3r3 is the flag: " + FLAG);
    }
});

/* put the js on local side for the CORS reason */
router.get('/js/:uuid', function (req, res) {
    if (req.params.hasOwnProperty('uuid')) {
        const uuid = req.params.uuid;
        if (apis.has(uuid)) {
            res.setHeader("Content-Security-Policy", "script-src 'nonce-XssFun'");
            res.send(apis.get(uuid));
        } else {
            res.send("Not Found")
        }
    } else {
        res.send("Missing uuid");
    }
});

/* report to the bot */
router.get('/report', function (req, res) {
    if (req.query.hasOwnProperty('uuid')) {
        const uuid = req.query.uuid;
        if (apis.has(uuid)) {
            visit('http://127.0.0.1:8080/js/' + uuid).then(r => {
                res.send("Finished");
            }).catch(error => {
                res.send("puppeteer error");
            });
        } else {
            res.send("uuid not registered yet")
        }
    } else {
        res.send("Missing uuid");
    }
});

/* api register */
router.get('/register/:domain', async function (req, res) {
    if (req.params.hasOwnProperty('domain')) {
        let resp, data;
        const domain = req.params.domain
        const scheme = domain.includes('ngrok') ? 'https' : 'http';
        const url = `${scheme}://${domain}/`;

        // 你的api需要经过如下检测
        // test the first api: http://domain/test?name=xxx
        const rand = randGenerate(10, 20);

        try {
            ({resp, data} = await sendRequest(url + "test?name=" + rand, {'headers': {}}));
        } catch (err) {
            console.log(err);
            res.send(`${url} test api error`);
            return;
        }

        const contentType = resp.headers['content-type'];
        if (contentType !== 'application/json') {
            res.send("content-type should be application/json")
            return;
        }

        let body = JSON.parse(data);
        let len = body['len'];
        let code = body['code'];
        if (len !== rand.length || code !== 200) {
            res.send("len or code wrong");
            return;
        }

        // test the second api: http://domain/redirect
        for (let i = 0; i < 4; i++) {
            const choice = Math.floor(Math.random() * 10) % 2 === 0
            const options = {
                headers: {
                    'Referer': choice ? url : 'http://evil/'
                }
            };

            try {
                ({resp, data} = await sendRequest(url + "redirect", options));
            } catch (err) {
                res.send(`${url} redirect api error`);
                return;
            }
            const statusCode = resp.statusCode;

            if (choice) {
                // Even Num for http://domain/
                if (statusCode === 302) {
                    if (resp.headers['location'] !== `${url}success`) {
                        res.send("location wrong");
                        return;
                    }
                } else {

                    res.send("status code should be 302 qwq");
                    return;
                }
            } else {
                // Odd Num for http://evil
                if (statusCode === 404) {
                    if (data !== 'this is forbidden') {
                        res.send("Forbidden Me :)");
                        return;
                    }
                } else {
                    res.send("status code should be 404 qwq");
                    return;
                }
            }
        }

        // test the third api: http://domain/js
        try {
            ({_, data} = await sendRequest(url + "js", {'headers': {}}));
        } catch (err) {
            res.send(`${url} js api error`);
            return;
        }
        const jsCode = data;
        const uuid = uuidv4();
        apis.set(uuid, jsCode);
        res.send("congrats! your uuid is: " + uuid);
    } else {
        res.send("Missing parameter <domain>")
    }
});

module.exports = router;
